/**
 * Base de Conocimientos del Tutor Académico
 */

export const KNOWLEDGE_BASE = {
  porter_que_es_estrategia: `
    ¿QUÉ ES LA ESTRATEGIA? por Michael E. Porter (Harvard Business Review)

    I. LA EFICACIA OPERACIONAL NO ES ESTRATEGIA
    La raíz del problema radica en una incapacidad de distinguir entre eficacia operacional y estrategia. La búsqueda de productividad, calidad y velocidad ha generado una cantidad extraordinaria de herramientas y técnicas de gestión (TQM, benchmarking, reingeniería). Aunque las mejoras operacionales han sido impresionantes, muchas empresas no han logrado convertirlas en rentabilidad sustentable.

    Eficacia Operacional (EO): Significa realizar las mismas actividades mejor que los rivales. Incluye la eficiencia pero no se limita a ella. Se refiere a cualquier práctica que permita a una empresa hacer mejor uso de sus insumos.
    Posicionamiento Estratégico: Implica realizar actividades diferentes de aquellas de los rivales, o bien realizar actividades similares de manera diferente.

    La frontera de la productividad: Es el máximo valor que una empresa puede crear a un costo dado, usando las mejores tecnologías, habilidades y técnicas de gestión disponibles. Cuando una empresa mejora su EO, se acerca a la frontera. La competencia por la EO expande la frontera, elevando la vara para todos pero no implica una mejora relativa para ninguna empresa en particular (convergencia competitiva).

    II. LA ESTRATEGIA DESCANSA SOBRE ACTIVIDADES ÚNICAS
    La estrategia competitiva consiste en ser diferente. Significa la selección deliberada de un conjunto de actividades distintas para entregar una mezcla única de valor.
    Ejemplos:
    - Southwest Airlines: Vuelos cortos, punto a punto, bajo costo, aeropuertos secundarios. Evita comidas, asientos numerados y transferencias de equipaje.
    - IKEA: Posicionamiento basado en las necesidades de clientes jóvenes que desean muebles con estilo a bajo costo. Autoservicio, muebles modulares listos para armar, exhibiciones estructuradas.

    Orígenes de las posiciones estratégicas:
    1. Posicionamiento basado en la variedad: Basado en la elección de variedades de productos o servicios más que en segmentos de clientes (ej. Jiffy Lube, Vanguard).
    2. Posicionamiento basado en las necesidades: Satisfacer la mayoría o todas las necesidades de un grupo de clientes particular (ej. IKEA, Bessemer Trust).
    3. Posicionamiento basado en el acceso: Segmentar clientes que son asequibles de distintas maneras (ubicación geográfica, escala) (ej. Carmike Cinemas).

    III. UNA POSICIÓN ESTRATÉGICA SUSTENTABLE REQUIERE TRADE-OFFS
    Los trade-offs ocurren cuando las actividades son incompatibles. Un trade-off significa que para tener más de algo, hay que tener menos de otra cosa.
    Razones de los trade-offs:
    1. Contradicciones en la imagen o reputación.
    2. Las actividades mismas (diferentes posiciones requieren diferentes configuraciones).
    3. Límites para la coordinación y el control internos.
    Ejemplo de fracaso por no aceptar trade-offs: Continental Lite intentó imitar a Southwest sin abandonar su servicio completo (abarcamiento), lo que generó ineficiencias masivas.

    IV. EL CALCE IMPULSA LA VENTAJA COMPETITIVA Y LA SUSTENTABILIDAD
    La estrategia consiste en combinar actividades. El calce (fit) aleja a los imitadores al crear una cadena resistente donde el todo es más importante que las partes.
    Tipos de calce:
    1. Primer orden: Coherencia simple entre cada actividad y la estrategia general.
    2. Segundo orden: Las actividades se refuerzan entre sí.
    3. Tercer orden: Optimización del esfuerzo (coordinación e intercambio de información para eliminar redundancias).

    V. REDESCUBRIR LA ESTRATEGIA
    La mayor amenaza para la estrategia a menudo proviene del interior de la empresa (deseo de crecer, errores organizacionales).
    La trampa del crecimiento: El deseo de crecer lleva a los ejecutivos a ampliar las líneas de productos o atender nuevos clientes, eliminando trade-offs y desdibujando la posición estratégica original.
    Papel del liderazgo: Definir y comunicar la posición exclusiva de la empresa, hacer trade-offs y forjar el calce entre las actividades. El líder debe saber decir "no".
  `,
  porter_5_fuerzas: `
    LAS CINCO FUERZAS COMPETITIVAS QUE LE DAN FORMA A LA ESTRATEGIA por Michael E. Porter

    La esencia del trabajo del estratega es comprender y enfrentar la competencia. La competencia por las utilidades va más allá de los rivales directos e incluye cuatro otras fuerzas competitivas: clientes, proveedores, posibles entrantes y productos substitutos.

    1. AMENAZA DE ENTRADA:
    Los nuevos entrantes ponen límites a la rentabilidad. Cuando la amenaza es alta, los actores establecidos deben mantener precios bajos o incrementar la inversión.
    Barreras de entrada (7 fuentes):
    - Economías de escala por el lado de la oferta: Producir a volúmenes más grandes reduce costos unitarios.
    - Beneficios de escala por el lado de la demanda (Efectos de red): La disposición a pagar aumenta con el número de otros compradores.
    - Costos para los clientes por cambiar de proveedor: Costos fijos al cambiar de proveedor (ej. software SAP).
    - Requisitos de capital: Necesidad de invertir grandes sumas financieras.
    - Ventajas de los actores establecidos independientemente del tamaño: Tecnología propietaria, acceso a materias primas, identidades de marca.
    - Acceso desigual a los canales de distribución: Dificultad para desplazar a otros de la góndola.
    - Políticas gubernamentales restrictivas: Licencias, restricciones a inversión extranjera.

    2. EL PODER DE LOS PROVEEDORES:
    Capturan valor cobrando precios más altos o restringiendo calidad. Un grupo de proveedores es poderoso si:
    - Está más concentrado que el sector al cual le vende.
    - No depende fuertemente del sector para sus ingresos.
    - Los participantes del sector enfrentan costos por cambiar de proveedor.
    - Ofrecen productos diferenciados o no hay substitutos.
    - Pueden amenazar creíblemente con integrarse hacia adelante en el sector.

    3. EL PODER DE LOS COMPRADORES:
    Clientes poderosos pueden obligar a bajar precios o exigir mejor calidad. Un grupo de clientes es poderoso si:
    - Hay pocos compradores o compran en grandes volúmenes.
    - Los productos del sector son estandarizados o no se diferencian.
    - Los compradores enfrentan pocos costos por cambiar de proveedor.
    - Pueden amenazar creíblemente con integrarse hacia atrás (fabricar ellos mismos).
    Sensibilidad al precio: Aumenta si el producto representa una parte importante de sus costos o si tienen utilidades bajas.

    4. LA AMENAZA DE LOS SUBSTITUTOS:
    Un substituto cumple la misma función por medios distintos (ej. e-mail vs correo postal). La amenaza es alta si:
    - Ofrece un atractivo trade-off de precio y desempeño.
    - El costo para el comprador por cambiar al substituto es bajo.

    5. RIVALIDAD ENTRE COMPETIDORES EXISTENTES:
    Adopta formas como descuentos, lanzamientos o mejoras de servicio. La rivalidad es intensa si:
    - Los competidores son varios o iguales en tamaño.
    - El crecimiento del sector es lento.
    - Las barreras de salida son altas.
    La rivalidad de precios es especialmente destructiva porque transfiere utilidades directamente a los clientes.

    FACTORES, NO FUERZAS (Errores comunes):
    - Tasa de crecimiento del sector: El crecimiento rápido no garantiza rentabilidad.
    - Tecnología e innovación: No hacen por sí solas que un sector sea atractivo.
    - Gobierno: No es una sexta fuerza; influye a través de las cinco fuerzas.
    - Productos complementarios: Afectan la rentabilidad influyendo en las cinco fuerzas (ej. iTunes y CDs).

    IMPLICANCIAS ESTRATÉGICAS:
    - Posicionamiento: Construir defensas o encontrar una posición donde las fuerzas sean más débiles (ej. Paccar en camiones pesados centrándose en propietarios-operadores).
    - Dar forma a la estructura: Redividir la rentabilidad (neutralizar poder de proveedores/compradores) o expandir la fuente de utilidades (aumentar el valor total del sector).
  `,
  implementacion_estrategia: `
    [Pega aquí el contenido de "Nota sobre la implementación de la estrategia"]
  `,
  marca_viviente: `
    CREAR UNA MARCA VIVIENTE por Neeli Bendapudi y Venkat Bendapudi (Harvard Business Review)

    CONCEPTO CENTRAL:
    Cualquier empresa puede entregar un servicio extraordinario si considera a sus empleados como su "marca viviente". El secreto es crear un vínculo sólido entre los empleados y la marca, invirtiendo en ellos para que reflejen los valores básicos de la empresa.

    CASOS DE ÉXITO: QuikTrip (QT) y Wawa.
    - Rotación: 14% en QT y 22% en Wawa (promedio del sector suele ser de tres dígitos).
    - Desempeño: Wawa creció al 17% anual y QT al 19,2%, superando ampliamente al S&P 500.

    LAS SEIS LECCIONES DE LA MARCA VIVIENTE:
    1. SABER LO QUE SE BUSCA: Definir rasgos intrínsecos (personas "agradables" o con "pasión"). Contratación centralizada.
    2. APROVECHAR AL MÁXIMO EL TALENTO: Capacitación intensiva y mentoría. Educación continua (reembolso de estudios).
    3. GENERAR ORGULLO EN LA MARCA: Sacrificios por el cliente para proteger la imagen.
    4. CONSTRUIR COMUNIDAD: Amabilidad extrema, apoyo interno entre tiendas y recompensas grupales.
    5. COMPARTIR EL CONTEXTO DEL NEGOCIO: Transparencia financiera y tolerancia al error bien intencionado.
    6. SATISFACER EL ALMA: Seguridad, Estima (celebrar éxitos) y Justicia (participación en utilidades).
  `,
  manejo_marca: `
    MARCAS Y EL MANEJO DE LA MARCA por Douglas B. Holt (Harvard Business School)

    PERSPECTIVA ESTRATÉGICA:
    El manejo de la marca no es solo publicidad; es un punto de vista estratégico central para crear valor y ventaja competitiva. La marca es el producto tal como es experimentado y valorado en la vida social.

    CULTURAS DE LA MARCA:
    Las marcas son "culturas" que adquieren significados conforme circulan en la sociedad. Los marcadores (nombres, logos) están "vacíos" al inicio y se llenan con historias, imágenes y asociaciones.

    LOS CUATRO AUTORES DE LA MARCA:
    1. Empresas: A través de todas las actividades de la mezcla comercial.
    2. Cultura Popular: Uso en películas, TV, noticias o parodias.
    3. Clientes: Historias de consumo compartidas.
    4. Los que Influyen: Expertos, revistas especializadas, vendedores.

    LOS CUATRO COMPONENTES DEL VALOR DE LA MARCA:
    1. Valor de la Reputación: Señal de calidad y confiabilidad que reduce el riesgo del cliente.
    2. Valor de la Relación: Percepción de la empresa como socio confiable a largo plazo ante contingencias.
    3. Valor de las Experiencias: Marco perceptual que guía los sentidos y forma la experiencia subjetiva.
    4. Valor Simbólico: Expresión de valores e identidades (estatus, solidaridad).

    INGENIERÍA DE LA MARCA:
    Implica diseñar de forma coherente todos los aspectos de la mezcla comercial (producto, empaque, precio, canales, comunicación) para reforzar la cultura de marca deseada.

    ÉTICA EN EL MANEJO DE LA MARCA:
    Para ser benévola, requiere: igualdad de información, sofisticación del consumidor, baja dependencia de heurísticos y transparencia sobre los autores.
  `,
  segmentacion_mercado: `
    REDESCUBRIENDO LA SEGMENTACIÓN DE MERCADO por Daniel Yankelovich y David Meer (Harvard Business Review)

    PROPÓSITO ORIGINAL:
    Descubrir clientes cuyo comportamiento puede ser cambiado o cuyas necesidades no se están satisfaciendo. La segmentación debe guiar la innovación de productos, la selección de canales y la estrategia, no solo la publicidad.

    EL FALLO DE LA PSICOGRAFÍA:
    La psicografía (crear tipos humanos con apodos como "Harry el tecnófilo") es útil para fortalecer la identidad de marca y la conexión emocional en la publicidad, pero es muy débil para predecir el comportamiento de compra real en categorías específicas.

    EL ESPECTRO DE GRAVEDAD DE LA DECISIÓN:
    Herramienta que indica que la profundidad del análisis debe depender de la importancia de la decisión para el consumidor:
    1. EXTREMO SUPERFICIAL: Productos funcionales y de bajo costo (ej. papel higiénico, snacks). Se debe medir sensibilidad al precio, hábitos e impulsividad.
    2. CENTRO DEL ESPECTRO: Grandes compras (ej. autos, electrónica). Se evalúa preocupación por calidad, diseño, complejidad y estatus.
    3. EXTREMO PROFUNDO: Alta inversión emocional y valores centrales (ej. salud, finanzas, donde vivir). Se deben exponer las tensiones entre valores personales y de mercado.

    ANÁLISIS CONJUNTO (CONJOINT ANALYSIS):
    Técnica que presenta a los consumidores combinaciones de características de un producto para medir su disposición a comprar si se agregan, eliminan o cambian precios. Permite optimizar el producto sin elevar el precio innecesariamente.

    CARACTERÍSTICAS DE UNA SEGMENTACIÓN EFICAZ:
    - Dinámica: Se concentra en necesidades y comportamientos que cambian rápidamente, no en rasgos de personalidad inmutables.
    - Intuitiva: Debe tener sentido para los altos ejecutivos y no depender excesivamente de tecnicismos estadísticos ("virtuosismo técnico").
    - Enfocada en el comportamiento real: Frecuencia de uso, cambio de marcas y lealtad.

    TRES MOTIVOS DE FRACASO:
    1. Interés excesivo en las identidades (casting central) en lugar de las características del producto.
    2. Poco énfasis en el comportamiento real del consumidor.
    3. Absorción indebida en detalles técnicos que alejan al marketing de la toma de decisiones.
  `,
  posicionamiento_estrategico: `
    POSICIONAMIENTO ESTRATÉGICO: Insights de Harvard Business Review (Adisu Fanta Bate)

    CONCEPTO DE ESTRATEGIA:
    - Porter: "La creación de una posición única y valiosa, que involucra un conjunto diferente de actividades".
    - Diferencia fundamental: La Eficacia Operacional (OE) es hacer las mismas actividades mejor que los rivales. El Posicionamiento Estratégico es hacer actividades diferentes o hacer actividades similares de maneras distintas.

    TIPOS DE POSICIONAMIENTO ESTRATÉGICO (Porter):
    1. POSICIONAMIENTO BASADO EN LA VARIEDAD: Se basa en producir un subconjunto de los productos o servicios de una industria. Satisface "pocas necesidades de muchos clientes" (Ej. Jiffy Lube en lubricantes, Southwest Airlines en vuelos punto a punto).
    2. POSICIONAMIENTO BASADO EN LAS NECESIDADES: Se enfoca en satisfacer la mayoría o todas las necesidades de un grupo particular de clientes. Requiere un conjunto distintivo de actividades para ese segmento (Ej. IKEA para jóvenes que buscan estilo a bajo costo).
    3. POSICIONAMIENTO BASADO EN EL ACCESO: Segmenta clientes basándose en su accesibilidad (geográfica o de escala). Requiere actividades distintas para llegar a ellos (Ej. Carmike Cinemas en ciudades pequeñas de menos de 200,000 habitantes).

    NUEVAS PERSPECTIVAS (Bate):
    - POSICIONAMIENTO HÍBRIDO: Surge cuando una empresa combina dos o más tipos de posicionamiento al expandirse, permitiéndole servir "amplias necesidades de amplios clientes" (Ej. Walmart, Amazon, Alibaba).
    - DESPLAZAMIENTO HACIA EL "DOWNSTREAM": La ventaja competitiva se está moviendo de las actividades de producción (upstream) hacia las actividades relacionadas con el cliente, la lealtad y las soluciones integradas (downstream).

    CONCEPTOS CLAVE DE SUSTENTABILIDAD:
    - EL "CALCE" (FIT): La ventaja no proviene de actividades individuales, sino de la integración y el ajuste de todo el sistema de actividades que se refuerzan mutuamente.
    - STRADDLING: El error de intentar adoptar una nueva posición manteniendo la existente sin aceptar los trade-offs necesarios (Ej. El fracaso de Continental Airlines al intentar imitar a Southwest).
    - TRAMPA DEL CRECIMIENTO: El deseo de crecimiento rápido puede diluir la distinción de la empresa y debilitar el calce de sus actividades. Se recomienda "profundizar" la posición en lugar de ampliarla indiscriminadamente.
    - CAPITAL GERENCIAL: Factor clave que marca una diferencia persistente en el desempeño y la excelencia operativa.
  `
};
